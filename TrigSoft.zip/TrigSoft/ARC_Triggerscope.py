from tkinter import *
import tkinter
from time import*
import time
import serial
import serial.tools.list_ports
import functools

tgS = serial.Serial()          # Sets tgS as serial
portSelect = 0               # Declares and sets portSelect to 0
tgsCom = "NONE"             #Sets tgsCom to be "None" this allows
activePort = "Off"            # Sets activePort to "Off"

def Open_COM():               # Definition that declares the parameters for the ports
  global tgsCom
  global tgS
  tgS = serial.Serial()       #Re-declares tgS as serial
  tgS.baudrate = 115200       # Sets the baudrate to 115200, which is necessary for the Triggerscope
  tgS.port = tgsCom            #Sets the port to be the result of tgsCom
  tgS.bytesize = serial.EIGHTBITS  # number of bits per bytes
  tgS.parity = serial.PARITY_NONE  # set parity check: no parity
  tgS.stopbits = serial.STOPBITS_ONE  # number of stop bits
  # tgS.timeout = None          #block read
  tgS.timeout = 0.5  # non-block read
  tgS.xonxoff = False  # disable software flow control
  tgS.rtscts = False  # disable hardware (RTS/CTS) flow control
  tgS.dsrdtr = False  # disable hardware (DSR/DTR) flow control
  tgS.writeTimeout = 0  # timeout for write

def on_select(selection):  # open the port and command it to start the LED blinking here
  global tgsCom
  default = StringVar(root, selection)  # Makes default = the selection
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom  # makes tgsCom work for OS
  Reduced = tgsCom.split()      # Variable that will soon reduce the selection of characters
  tgsCom = (Reduced[0])       #Sets tgsCom to be the Reduced character selection
  default.get()  # opens the value of default in order to see a change
  print("ComboBox Has selected " + default.get() + " on mouse click")
  print("Truncated to " + tgsCom + " for compatability ")

pnum = 0  # Port number, set to 0

def OPENCOM():  # Def OPENCOM set to the OPENCOM button.
  global tgsCom
  global portSelect
  global activePort
  # print(myPort)           #prints the myPort variable
  # print(portSelect)       #Prints the value of portSelect
  portSelect = tgsCom  # sets the portSelect value to be the same as tgsCom
  activePort = portSelect       #assigns activeport the result of portSelect
  if portSelect != "None":  # If the value of portSelect doesn't = none, then excute the command
    Open_COM()              #Runs the Open_COM def, which opens the selcted port.
    try:  # Begins the command
      print("Activating Triggerscope...")  # Prints activiating TRGSCPE
      tgS.open()  # Opens tgS
    except Exception as e:
      print("ERROR: Triggerscope Com port NOT OPEN: " + str(e))
      #exit()
      SLight.config(bg="red")
    if tgS.isOpen():
      try:
        tgS.flushInput()  # flush input buffer, discarding all its contents
        tgS.flushOutput()  # flush output buffer, aborting current output
        tgS.write("*\n".encode())  # send an ack to tgs to make sure it's up
        time.sleep(0.3)  # give the serial port sometime to receive the data
        print("Rx: " + tgS.readline().decode())
        print("Triggerscope Port is Open")
        SLight.config(bg="Green2")
        Port_Ranges()
      except Exception as e1:
        print("triggerscope serial communication error...: " + str(e1))

    else:
      print("cannot open triggerscope port ")
      Slight.config(bg="red")



def writetgs(tgin):
  '''send a serial command to the triggerscope...
              Args:
                  tgin: input string to send. Note the command terminator should be included in the string.
              Returns:
                  char string of whatever comes back on the serial line.
              Raises:
                  none.
              '''
  scomp = '!' + tgin
  tgS.flushInput()  # flush input buffer, discarding all its contents
  tgS.flushOutput()  # flush output buffer, aborting current output
  tgS.write(tgin.encode())  # send an ack to tgs to make sure it's up
  time.sleep(0.1)  # give the serial port sometime to receive the data 50ms works well...
  bufa = ""
  bufa = tgS.readline().decode()
  return bufa

def quit():
  root.destroy()

class ToolTip(object):

  def __init__(self, widget):
    self.widget = widget
    self.tipwindow = None
    self.id = None
    self.x = self.y = 0

  def showtip(self, text):
    self.text = text
    Status_Label.configure(text = text)

  def hidetip(self):
    Status_Label.config(text = "")

def CreateToolTip(widget, text):
  toolTip = ToolTip(widget)

  def enter(event):
    toolTip.showtip(text)

  def leave(event):
    toolTip.hidetip()

  widget.bind('<Enter>', enter)
  widget.bind('<Leave>', leave)

# ****** Functions/software *******

root = Tk()       # Root
root.configure(bg="grey90")

Grid.rowconfigure(root, 0, weight=1)    #Creating the base grid
Grid.columnconfigure(root, 0, weight=1)   #Setting the columns to the grid

frame=Frame(root, bg="grey80", highlightbackground="black", highlightthickness=1)      #Frame has been created
frame.grid(row=1, column=1)
Grid.rowconfigure(frame, 0, weight=1)
Grid.columnconfigure(frame, 0, weight=1)

button1 = Button(text = "Quit", command = quit) #Quit Button that exits the program
button1.configure(width = 10, activebackground = "#33B5E5", relief = RAISED) #gives the button detail
button1.grid(row= 0, column=0, sticky = N+W)
CreateToolTip(button1, text = "Closes the Application")


ports = serial.tools.list_ports.comports()      # Sets "ports" to be the list of COM ports.

if (ports==[]):                       # Statement to give the COM port box a value even when no port is connected
  ports.append("No Ports Connected...")
  ports.append("Please Connect A COM Port To Continue")
else:
  print (ports)

default = StringVar(root, "Please Select Port")       # Sets default as "Please Select Port", which shows on the port dropdown bar
myPort = StringVar(root)            # Defs the myPort
myPort.set("Please Select Port")              # Makes the stringvar's value = "None"
portSelect = OptionMenu(root, myPort, *ports, command=on_select) #The Option menu is set, with the command of on_select
portSelect.grid(row=1, column = 0)
CreateToolTip(portSelect, text = "Select a connected port then press the open port button")      #The description at the bottom of the app when hovering over the port bar.

OPENPORT = Button(text = "Open Port", command = OPENCOM)     #Button that opens the communication to the COM port
OPENPORT.grid(row =2 , column=0)
CreateToolTip(OPENPORT, text = "Opens the selected port")            #The description at the bottom of the app when hovering over the open port button

Status = Label(text = "Port Status:", bg = "grey90", fg="black")
Status.grid(row=1, column= 0, pady=(75,0))

SLight = Label(bg= "red", width = 1)
SLight.grid(row=1, column= 0, pady=(75,0), padx= (80,0))

Status_Label = Label(text="", bg="grey80", bd=1, relief=SUNKEN, anchor=E)   #Status bar at the bottom of the window that provides a description of buttons
Status_Label.grid(row=6, column=0, columnspan = 5, sticky=N+S+E+W)


#****** Root/title/Frames ******
root.title("ARC Triggerscope Regulator")     # title of root window



btn_list = [] # List to hold the button objects
dv = list()
rv = list()
OPTIONS =list()

G = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
F = []
COLOR = list()

DAC_List = list()

def Switch(idx):
  global G
  G[idx] = 1


def Switch2(idx):
  global G
  G[idx] = 0

DacVal= [0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0]
RangeVal=[0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0]

Test_Label = Label(text="ARC IQC Test Run:")  # Quit Button that exits the program
Test_Label.configure(activebackground="#33B5E5", relief=FLAT, bg='grey90', fg="grey90")  # gives the button detail
Test_Label.grid(row=4, column=1, sticky=W)

variable = []
OPTIONS = []
Range_menu = []
Range_val = []
ADV = 0
ADVC = 0
NRM = 0
rv = list()
rs = [0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0]
A = ()
RANGEVAL = []
TRUERANGE = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
q = 3
variable = StringVar()


def Set_Range(selection):
    f = 0
    for x in rv:
        D = x.cget("text")
        if (D != RangeVal[f] and D != "RANGE"):
            # print("D = " + str(D) + " Rangeval=" + str(RangeVal[f]))
            out = "RANGE" + str(f + 1) + "," + str(
                D[:1]) + "\n"  # Makes "Out" the current variable of the corrisponding scale
            # print(out)
            print(writetgs(out))  # Print the command the trigerscope got, Should be to set it to whatever number it is.
            RangeVal[f] = D
            # print(RangeVal)
        f = f + 1


def main(height=4,width=4):
  flipper = TRUE

  def Save():
    global RANGEVAL
    global TRUERANGE
    global q
    print(writetgs("SAVESETTINGS" + "\n"))
    print(writetgs("RESET" + "\n"))
    sleep(.5)
    a = (writetgs("STAT?"+"\n"))
    time.sleep(0.02)

  def updateButtonlabels():
    for x in range(16):
      if (G[x] == 1):
        Toff.config(bg='green2')
      else:
        Toff.config(bg='red')
        # make label red



  def dacUpdate(barf):
    #print(barf)
    f = 0
    for i in dv:
      D = i.get()
      if (D != DacVal[f]):
        out = "DAC" + str(f+1) + "," + str(D) + "\n"  #Makes "Out" the current variable of the corrisponding scale
        print(writetgs(out))  #Print the command the trigerscope got, Should be to set it to whatever number it is.
        DacVal[f] = D
      f = f + 1

  def toggle(idx):  # Toggle animation for TTL Buttons as well as opening the labelsensor def
    if (idx <= 7):
      idx= idx+1
      global G
      if (G[idx] == 0):
        print(writetgs("TTL" + str(idx+1) + ",1\n"))
        F[idx].config(bg = "green2")
        Switch(idx)
      else:
        print(writetgs("TTL" + str(idx+1) + ",0\n"))
        F[idx].config(bg = "red")
        Switch2(idx)

    if (idx >= 8):
      if (G[idx] == 0):
        print(writetgs("TTL" + str(idx+1) + ",1\n"))
        F[idx].config(bg="green2")
        if (idx == 15):
          F[idx].config(bg = "green2")
        print(idx)
        Switch(idx)
      else:
        print(writetgs("TTL" + str(idx+1) + ",0\n"))
        F[idx].config(bg="red")
        Switch2(idx)
    updateButtonlabels()
    #print(G)


  for y in range(height):
    for x in range(width):
      Tname = ""
      Lname = ""
      Rname = ""
      Dname = ""
      if(flipper):
        Tname = "TTL:" + str(x+1)
        Lname = "DAC" +str(x+1) + ":"+ " 0-65535"
        Rname = "Range" +str(x+1) + ""
      if(not flipper):
        Tname = "TTL:" + str(x+1)
        Lname = "DAC" + str(x+1) +":"+ " 0-65535"
        Rname = "Range" + str(x + 1) + ""

      if (y == 0):
        TTL = tkinter.Button(frame, bg = "grey90", fg="black", text = Tname, command = lambda idx = x: toggle(idx-1))
        TTL.grid(column=x, row=y, padx= 50, pady =(20,0))
        CreateToolTip(TTL, text = "Turns the TTL ON/OFF. Output of 5V     ")
        Toff = Label(frame, bg="red", width = 1)
        Toff.grid(column=x, row=y, sticky = E, padx = 15, pady= (20,0))
        F.append(Toff)
        COLOR.append(TTL)
        #print (Toff)
        if (x == 7):
          break

      if (y == 1):
        global variable
        DAC = Scale(frame, width=13, from_=0, to=65535, orient=HORIZONTAL,bg="grey90", fg="black", highlightbackground="skyblue")
        DAC.grid(column=x, row=y+1, pady=(0,65))
        CreateToolTip(DAC, text="Sets the range for the DAC outputs, Range is 0-10V     ")
        DAC.configure(relief=RAISED)  # make the relief of the scale flat
        DAC.bind("<ButtonRelease>",dacUpdate)  # Bind the scale to run the dacUpdate command when the curser is done selecting the amount
        dv.append(DAC)
        DAC_Label = Label(frame, text= Lname,bg="grey80")
        DAC_Label.grid(column=x, row=y+1,pady =(0,0), padx=15)
        DAC_List.append(DAC_Label)
        OPTIONS = ["1.  0/5V", "2.  0/10V", "3.  -5/5V", "4.  -10/10V", "5.  -2.5/2.5V"]  # etc
        variable = StringVar(root)
        variable.set("RANGE")  # default value
        Range = OptionMenu(frame, variable,*OPTIONS, command = Set_Range)
        Range.config(bg="grey90", fg="black", highlightbackground="grey80")
        Range.grid(column=x, row=y+1,pady =(75,20), padx=15)
        rv.append(Range)
        if (x == 7):
          break

      if (y == 3):
        Tname2 = "TTL:" + str(x + 9)
        TTL = tkinter.Button(frame, bg="grey90",fg="black", text = Tname2, command = lambda idx = x + 9: toggle(idx-1))
        TTL.grid(column=x, row=y, pady=(20,0))
        CreateToolTip(TTL, text="Turns the TTL ON/OFF. Output of 5V")
        Toff = Label(frame, bg="red", width = 1)
        Toff.grid(column=x, row=y, sticky = E, padx = 14, pady=(20,0))
        F.append(Toff)
        COLOR.append(TTL)
        #print(Toff)
        if (x == 7):
          break


      if (y == 4):
        Lname2 = "DAC" + str(x + 9) + ":" + " 0-65535"
        #nam.append(Scale(master, from_=100, to=0, orient=VERTICAL))
        DAC = Scale(frame, width=13, from_=0, to=65535, orient=HORIZONTAL, bg="grey90", fg="black", highlightbackground="skyblue")
        DAC.grid(column=x, row=y+1, pady = (0,65))
        CreateToolTip(DAC, text="Sets the range for the DAC outputs, Range is 0-10V     ")
        DAC.configure(relief=RAISED)  # make the relief of the scale flat
        DAC.bind("<ButtonRelease>", dacUpdate)
        dv.append(DAC)
        DAC_Label = Label(frame, text=Lname2, bg="grey80")
        DAC_Label.grid(column=x, row=y+1, pady=(0,0), padx=15)
        DAC_List.append(DAC_Label)
        OPTIONS = ["1.  0/5V", "2.  0/10V", "3.  -5/5V", "4.  -10/10V", "5.  -2.5/2.5V"]  # etc
        variable = StringVar()
        variable.set("RANGE")  # default value
        Range = OptionMenu(frame,variable, *OPTIONS, command = Set_Range)
        Range.config(bg="grey90", fg="black", highlightbackground="grey80")
        Range.grid(column=x, row=y+1,pady =(85,25), padx=15)
        rv.append(Range)
        #DAC.bind("<ButtonRelease>", dacPos)  # Bind the scale to run the dacPos command when the curser is done selecting the amount
        if (x == 7):
          break

      #print("Column = " +str(x) + "row="+str(y))
      flipper = not flipper
      #btn_list.append(TTL)  # Append the button to a list
      def classic():
        root.config(bg="grey90")
        frame.config(bg="grey80", highlightbackground="black")
        Status.config(bg="grey90", fg="black")
        button1.config(bg="grey90")
        DAC_Label.config(bg ="grey80", fg ="black")
        Status_Label.config(bg="grey80", fg="black")
        global ADVC
        ADVC = 0
        for x in range(16):
          dv[x].config(bg="grey90", fg="black", highlightbackground="skyblue")     #Adjusts the color of the DAC sliders
          DAC_List[x].config(bg="grey80", fg="black")
        for y in range(16):
          COLOR[y].config(bg="grey90", fg="black")     #Adjusts the color of the TTL buttons
        if (ADV == 0):
          print("Advanced mode off")
          Test_Label.config(bg="grey90", fg="grey90")
        else:
          print("Advanced mode is on")
          Test_Label.config(bg="grey90", fg="black")
        print("classic")

      def dark():
        root.config(bg="black")
        frame.config(bg="black", highlightbackground="white")
        Status.config(bg="black", fg="white")
        button1.config(bg="gold")
        Status_Label.config(bg="black", fg="white")
        global ADVC
        ADVC = 1
        for x in range(16):
          dv[x].config(bg="black", fg="green2", highlightbackground="white")
          DAC_List[x].config(bg="black", fg="white")
        print("dark")
        for y in range(16):
          COLOR[y].config(bg= "gold", fg= "black")
        if (ADV == 0):
          print("Advanced mode off")
          Test_Label.config(bg="black", fg="black")
        else:
          print("Advanced mode is on")
          Test_Label.config(bg="black", fg="white")


      my_menu = Menu(root)
      root.config(menu=my_menu)
      File_menu = Menu(my_menu)
      my_menu.add_cascade(label="File", menu = File_menu)
      File_menu.add_command(label="Save Range Values", command = Save)
      theme_menu = Menu(my_menu)
      my_menu.add_cascade(label="Theme", menu=theme_menu)
      theme_menu.add_command(label="Classic", command=classic)
      theme_menu.add_command(label="Dark", command=dark)
      Extras_menu = Menu(my_menu)
      my_menu.add_cascade(label="Extras", menu=Extras_menu)
      Extras_menu.add_command(label="Normal Mode", command=Normal_mode)
      Extras_menu.add_command(label="Advanced Mode", command = Advanced_mode)


  return frame

         #***** Triggerscope Testing ******
q = 3

def Port_Ranges():
    global TRUERANGE
    global RANGEVAL
    global q
    a = (writetgs("STAT?" + "\n"))
    time.sleep(0.02)
    for n in range(3):
        time.sleep(0.2)
        bufa = ""
        bufa = tgS.readline()
        if (n == 2):
            b = str(bufa[11:])
            for letter in b:
                RANGEVAL.append(letter)
            for i in range(16):
                TRUERANGE[i] = int(RANGEVAL[q]) + 1
                q = q + 3
            print(TRUERANGE)
            if (TRUERANGE != [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]):
                h = TRUERANGE
                #print(h)
                #for x in range(16):
                    #print(TRUERANGE[x])
                    #if (TRUERANGE[x] != 2):
                        #print(x)
                        #print(TRUERANGE[x])
                        #print(rv[x])
                        #rv[x].config(bg = "lightblue")
                        #D = rv[x].cget("text")
                        #print(D)
                        #if (D == "RANGE"):
                           # rv[x].config(bg="lightblue")
                        #variable = (str(TRUERANGE[x]))
                        #rv[x].configure(variable)


                        #print(variable.get())
                        #variable.set(TRUERANGE[x])
                        #rv[x].config()
                        #if (x != 16):
                        #    print(TRUERANGE[x])
                        #    print(x)
                        #    break
                #for x in rv:
                    #D = x.cget("text")
                    #x.config(bg = "blue")
                    #print(x.cget())
                    #x.config(text = "HELLO")
                    #variable.set("HELLO")

def ALL_ON():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(12):
    #print("TTL" +str(x+1) + ",1\n")
    print(writetgs("TTL" +str(x+1) + ",1\n"))


def ALL_OFF():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(12):
    #print("TTL" +str(x+1) + ",1\n")
    print(writetgs("TTL" +str(x+1) + ",0\n"))


def Cycle_TTL():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(30):
    print(writetgs("TTL1,1\n"))
    print(writetgs("TTL1,0\n"))

def DAC_RANGE():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(16):
    print(writetgs("RANGE" + str(x + 1) + ",4\n"))
    print(writetgs("DAC" + str(x + 1) + ",0\n"))

def DAC_UPRANGE():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(16):
    print(writetgs("DAC" + str(x + 1) + ",65535\n"))

def DAC_RESET():
  tgsCom = default.get()  # Grabs the value of default
  tgsCom = tgsCom
  print(activePort)
  for x in range(16):
    print(writetgs("RANGE" + str(x + 1) + ",2\n"))
    print(writetgs("DAC" + str(x + 1) + ",0\n"))


print("Welcome to the ARC Trigggerscope Software!")
print("--To get started, choose a COM port and select open port...")

All_on = None     #Declaration to make the buttons have a value before existing
ALL_off = None    #Declaration to make the buttons have a value before existing
CYCLE_TTL = None      #Declaration to make the buttons have a value before existing
Range_dac = None      #Declaration to make the buttons have a value before existing
UpRange_dac = None      #Declaration to make the buttons have a value before existing
DAC_reset = None      #Declaration to make the buttons have a value before existing


def Advanced_mode():      #A mode that adds a set of "advanced buttons" typically used for testing the triggerscope
  global ADV
  ADV = 1
  if (ADVC == 0):       #Senses whether or not the theme is dark or classic, and changes the colors accordingly
    Test_Label.configure(activebackground="#33B5E5", relief=FLAT, bg='grey90', fg ="black")  # Allows a better look in classic mode
    Test_Label.grid(row=4, column=1, sticky=W)
  else:
    Test_Label.configure(activebackground="#33B5E5", relief=FLAT, bg='black', fg="white")  # Allows a better look in dark mode
    Test_Label.grid(row=4, column=1, sticky=W)

  global All_on
  All_on = Button(text = "Turn all TTL'S on", command = ALL_ON) #Quit Button that exits the program
  All_on.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  All_on.grid(row= 4, column=1, sticky = W, padx= 120)
  CreateToolTip(All_on, text="Turns all of the TTL outputs ON")     #The description at the bottom of the app when hovering over the Turn all TTL's on button

  global ALL_off
  ALL_off = Button(text = "Turn all TTL'S off", command = ALL_OFF) #Quit Button that exits the program
  ALL_off.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  ALL_off.grid(row= 4, column=1, sticky = W, padx= 240)
  CreateToolTip(ALL_off, text="Turns all of the TTL outputs OFF")      #The description at the bottom of the app when hovering over the ALL_off button

  global CYCLE_TTL
  CYCLE_TTL = Button(text = "Cycle TTL's", command = Cycle_TTL) #Quit Button that exits the program
  CYCLE_TTL.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  CYCLE_TTL.grid(row= 4, column=1, sticky = W, padx= 360)
  CreateToolTip(CYCLE_TTL, text="Turns TTL1 ON and OFF rapidly")       #The description at the bottom of the app when hovering over the Cycle TTL button

  global Range_dac
  Range_dac = Button(text = "DAC Low Range", command = DAC_RANGE) #Quit Button that exits the program
  Range_dac.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  Range_dac.grid(row= 4, column=1, sticky = W, padx= 450)
  CreateToolTip(Range_dac, text="Sets the range of ALL DAC outputs to maximum negative voltage")     #The description at the bottom of the app when hovering over the Range button

  global UpRange_dac
  UpRange_dac = Button(text = "DAC High Range", command = DAC_UPRANGE) #Quit Button that exits the program
  UpRange_dac.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  UpRange_dac.grid(row= 4, column=1, sticky = E, padx= 440)
  CreateToolTip(UpRange_dac, text="Sets the range of ALL DAC outputs to maximum positive voltage")       #The description at the bottom of the app when hovering over the Uprange button

  global DAC_reset
  DAC_reset = Button(text = "DAC Range Reset", command = DAC_RESET) #Quit Button that exits the program
  DAC_reset.configure(activebackground = "#33B5E5", relief = RAISED) #gives the button detail
  DAC_reset.grid(row= 4, column=1, sticky = E, padx= 315)
  CreateToolTip(DAC_reset, text="Resets the DAC outputs back to normal function")      #The description at the bottom of the app when hovering over the DAc_reset button


def Normal_mode(): #Function where it takes the existing advanced buttons and hides them. Making it normal mode again
  global ADV      # Variable to allow the Test_Label to change to the corrisponding color/Theme
  ADV = 0     #Sets ADV to 0 to allow the Test_Label to appear invisable
  global ADVC
  if (ADVC == 0):
    Test_Label.configure(activebackground="#33B5E5", relief=FLAT, bg='grey90', fg="grey90")  # gives the button detail
    Test_Label.grid(row=4, column=1, sticky=W)
  else:
    Test_Label.configure(activebackground="#33B5E5", relief=FLAT, bg='black', fg="black")  # gives the button detail
    Test_Label.grid(row=4, column=1, sticky=W)

  global All_on
  global ALL_off
  global CYCLE_TTL
  global Range_dac
  global UpRange_dac
  global DAC_reset
  All_on.destroy()
  ALL_off.destroy()
  CYCLE_TTL.destroy()
  Range_dac.destroy()
  UpRange_dac.destroy()
  DAC_reset.destroy()


w= main(5,16)
tkinter.mainloop()
